from typing import Callable


def create_proxy(f: Callable): ...
